function upload(){
    var vehiclenumber=document.getElementById("vehicle-number");
    var drivername=document.getElementById("driver-name");
    var status=document.getElementById("status");

    if(vehiclenumber===""||drivername===""||status===""){
        alert("enter Properly")
    }
       
  fetch('http://localhost:8080/api/vehiclesdetails',{
      method:"POST",
      headers:{
          "Content-Type":"application/json"
              },
              body:JSON.stringify({
                  vehiclenumber:vehiclenumber,
                  drivername:drivername,
                  status:status
              })
  })
  .then(res=>res.text())
  .then(data=>{
      if(data==="success"){
          alert("Successfully Upload");
      }else{
          alert("Its Error ");
      }
  });
}


let speeds=0;
let fuels=100;
let intervalId=null;

function startTracking() {
  
  if (intervalId !==null) return;

  intervalId = setInterval(function(){
    if (fuels > 0) {
      speeds += 5;
      fuels -= 2;

      document.querySelector(".speed").value= +speeds;
      document.querySelector(".fuel").value= +fuels;
    } else {
      stop();
    }
  },1000);

  fetch('http://localhost:8080/api/vehicletracking',{
    method:"POST",
    headers:{
        "Content-Type":"application/json"
            },
            body:JSON.stringify({
              speed:speed,
              fuel:fuel
                
            })
})
.then(res=>res.text())
.then(data=>{
    if(data==="success"){
        alert("Successfully Upload");
    }else{
        alert("Its Error ");
    }
});
}

function stop() {
  clearInterval(intervalId);
   intervalId = null;
  speeds=0;
  document.querySelector(".speed").value= +speeds;
}
