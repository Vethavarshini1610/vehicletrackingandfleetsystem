function login(){
    var username=document.getElementById("user-name").value;
    var email=document.getElementById("email").value;
    var password=document.getElementById("password").value;
    
    if(username===""||email===""||password===""){
        alert("please enter all above details");
        return
    }
    fetch('http://localhost:8080/api/users',{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    username:username,
                    emailid:email,
                    password:password
                })
    })
    .then(res=>res.text())
    .then(data=>{
        if(data==="success"){
            alert("Successfully Upload");
        }else{
            alert("Its Error ");
        }
    });
}





function submit(){
    var drivername=document.getElementById("driver-name").value;
    var phonenumber=document.getElementById("phone-number").value;
    var address=document.getElementById("address").value;
    var proff=document.getElementById("proff").value;
    if(drivername===""||phonenumber===""||address===""||proff===""){
        alert("please enter all above details");
    }
       
    fetch('http://localhost:8080/api/drivers/details',{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    drivername:drivername,
                    phonenumber:phonenumber,
                    address:address,
                    proff:proff
                })
    })
    .then(res=>res.text())
    .then(data=>{
        if(data==="success"){
            alert("Successfully Upload");
        }else{
            alert("Its Error ");
        }
    });
}




var totalCount=0;
var bikeCount=0;
var carCount=0;
function submitlist(){
    var vehiclename=document.getElementById("vehicle-name").value;
    var vehiclenumber=document.getElementById("vehicle-number").value;
    var bike=document.getElementById("bike").value;
    var car=document.getElementById("car").value;

    if(vehiclename==="" || vehiclenumber ===""){
        alert("vehicle name and number to enter properly");
        return;
    }
    
    if(vehiclename==="bike"){
        bikeCount++;
        totalCount++;
    }

   else  if(vehiclename==="car"){
        carCount++;
        totalCount++;
        
    }else{
        alert("Type only Bike or Car");
        return;
    }

    document.getElementById("bike").value=bikeCount;
    document.getElementById("car").value=carCount;
    document.getElementById("total").value=totalCount;

    fetch('http://localhost:8080/api/vehiclelist',{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    vehiclename:vehiclename,
                    vehiclenumber:vehiclenumber
                    
                })
    })
    .then(res=>res.text())
    .then(data=>{
        if(data==="success"){
            alert("Successfully Upload");
        }else{
            alert("Its Error ");
        }
    });
   
}