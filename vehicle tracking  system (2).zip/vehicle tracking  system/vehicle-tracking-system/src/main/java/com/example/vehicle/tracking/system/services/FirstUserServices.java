package com.example.vehicle.tracking.system.services;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.FirstUser;
import com.example.vehicle.tracking.system.repository.FirstUserRepository;


@Service
public class FirstUserServices{
    @Autowired
    
    
    FirstUserRepository repo;

    public List<FirstUser>getAllUsers(){
        return repo.findAll();
    }

    public FirstUser saveUser(FirstUser user){
        return repo.save(user);
    }
}