package com.example.vehicle.tracking.system.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class SecondDriver{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private String drivername;
    private String phonenumber;
    private String address;
    private String proff;


    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }


    public String getDrivername(){
        return drivername;
    }
    public void setDrivername(String drivername){
        this.drivername=drivername;
    }
    public String getPhonenumber(){
        return phonenumber;
    }
    public void setPhonenumber(String phonenumber){
        this.phonenumber=phonenumber;
    }
    public String getAddress(){   
        return address;
    }

    public void setAddress(String address){
        this.address=address;
    }
    public String getProff(){
        return proff;
    }
    public void setProff(String proff){
        this.proff=proff;
    }

}