package com.example.vehicle.tracking.system.repository;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.vehicle.tracking.system.model.SecondDriver;

@Repository
public interface SecondDriverRepo extends JpaRepository<SecondDriver, Long>{

}
