package com.example.vehicle.tracking.system.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class VehicleTracking{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private int speed;
    private int fuel;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public int getSpeed(){
        return speed;
    }
    public void setSpeed(int speed){
        this.speed=speed;
    }
    public int getFuel(){
        return fuel;
    }
    public void setFuel(int fuel){
        this.fuel=fuel;
    }
}