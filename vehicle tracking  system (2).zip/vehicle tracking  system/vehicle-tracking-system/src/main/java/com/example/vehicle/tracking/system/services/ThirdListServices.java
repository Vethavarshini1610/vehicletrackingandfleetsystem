package com.example.vehicle.tracking.system.services;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.ThirdList;
import com.example.vehicle.tracking.system.repository.ThirdListRepo;

@Service
public class ThirdListServices{
    @Autowired
    ThirdListRepo  repo;

    public List<ThirdList>getAllLists(){
        return repo.findAll();
    }

    public ThirdList saveList(ThirdList list){
        return repo.save(list);
    }
}