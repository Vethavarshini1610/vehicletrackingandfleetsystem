package com.example.vehicle.tracking.system.services;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.SecondDriver;
import com.example.vehicle.tracking.system.repository.SecondDriverRepo;


@Service
public class SecondDriverServices{
    @Autowired
    SecondDriverRepo repo;

    public List<SecondDriver>getAllDrivers(){
        return repo.findAll();
    }

    public SecondDriver saveDriver(SecondDriver driver){
        return repo.save(driver);
    }
}