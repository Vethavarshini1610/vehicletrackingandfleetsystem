package com.example.vehicle.tracking.system.services;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.VehicleDetails;
import com.example.vehicle.tracking.system.repository.VehicleDetailsRepo;

@Service

public class VehicleDetailsServices{
    @Autowired
    VehicleDetailsRepo repo;

    public List<VehicleDetails>getAllVehicles(){
        return repo.findAll();
    }
    public VehicleDetails saveVehicle(VehicleDetails vehicle){
        return  repo.save(vehicle);
    }
}