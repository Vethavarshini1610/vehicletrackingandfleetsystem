package com.example.vehicle.tracking.system.services;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vehicle.tracking.system.model.VehicleTracking;
import com.example.vehicle.tracking.system.repository.VehicleTrackingRepo;

@Service
public class VehicleTrackingServices{
    @Autowired
    VehicleTrackingRepo repo;

    public List<VehicleTracking>getAllTrackings(){
        return repo.findAll();
    }
    public VehicleTracking saveTracking(VehicleTracking tracking){
        return repo.save(tracking);
    }
}